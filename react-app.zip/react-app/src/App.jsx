import React from "react";
import { motion } from "framer-motion";

export default function App() {
  const emojis = ["🎬", "🍿", "😂", "😭", "👻", "🚗", "💘", "🦖", "🐧", "🛸"];

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-pink-100 to-blue-100 overflow-hidden">
      {/* 배경 이모지 */}
      {emojis.map((emoji, i) => (
        <motion.div
          key={i}
          className="absolute text-5xl opacity-30"
          style={{
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.3 }}
          transition={{ duration: 1.5, delay: i * 0.2 }}
        >
          {emoji}
        </motion.div>
      ))}

      {/* 제목 */}
      <h1 className="text-5xl font-bold mb-12 text-gray-800 drop-shadow-lg">
        🎬 이모지 영화 퀴즈 🍿
      </h1>

      {/* 버튼 영역 */}
      <div className="flex gap-6">
        <button className="px-6 py-3 text-xl rounded-2xl bg-blue-500 text-white shadow-md hover:bg-blue-600 transition">
          게임 시작
        </button>
        <button className="px-6 py-3 text-xl rounded-2xl bg-green-500 text-white shadow-md hover:bg-green-600 transition">
          설명 보기
        </button>
      </div>
    </div>
  );
}
