// js/out.js
function sayHello(name) {
    // window.alert(안녕하세요? + name + '님~');
}
