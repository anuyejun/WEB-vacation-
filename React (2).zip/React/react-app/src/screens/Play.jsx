import React, { useEffect, useMemo, useRef, useState } from 'react';
import './play.css';

// 초성 변환 함수
function toChosung(str) {
    const CHO = [
        'ㄱ',
        'ㄲ',
        'ㄴ',
        'ㄷ',
        'ㄸ',
        'ㄹ',
        'ㅁ',
        'ㅂ',
        'ㅃ',
        'ㅅ',
        'ㅆ',
        'ㅇ',
        'ㅈ',
        'ㅉ',
        'ㅊ',
        'ㅋ',
        'ㅌ',
        'ㅍ',
        'ㅎ',
    ];
    const BASE = 0xac00;
    const CHO_UNIT = 588;

    return Array.from(str || '')
        .map((ch) => {
            const code = ch.charCodeAt(0);
            if (code >= 0xac00 && code <= 0xd7a3) {
                const i = Math.floor((code - BASE) / CHO_UNIT);
                return CHO[i];
            }
            if (/\s/.test(ch)) return ' ';
            return '·';
        })
        .join('');
}

const normalize = (s) => (s || '').replace(/\s+/g, '').toLowerCase();

const MOCK_QUESTIONS = [
    {
        id: 1,
        emojis: ['🕵️', '💰', '🏃‍♂️'],
        answer: '도둑들',
        posterUrl: 'https://movie-phinf.pstatic.net/20210920_49/1632100234770FFmF7_JPEG/movie_image.jpg',
    },
    {
        id: 2,
        emojis: ['👹', '👦', '🧪'],
        answer: '괴물',
        posterUrl: 'https://movie-phinf.pstatic.net/20160907_262/1473239547495bNuEL_JPEG/movie_image.jpg',
    },
    {
        id: 3,
        emojis: ['👩‍👧', '🏠', '🐛'],
        answer: '기생충',
        posterUrl: 'https://movie-phinf.pstatic.net/20190514_214/1557832111417wTdrF_JPEG/movie_image.jpg',
    },
];

export default function Play({ onExit, onFinish }) {
    const [questions, setQuestions] = useState([]);
    const [qIdx, setQIdx] = useState(0);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    const [correct, setCorrect] = useState(0);
    const [hintCount, setHintCount] = useState(0);
    const [passCount, setPassCount] = useState(0);

    const [guess, setGuess] = useState('');
    const [hintUsed, setHintUsed] = useState(false);
    const [hintText, setHintText] = useState('');
    const [message, setMessage] = useState('');

    const [secondsLeft, setSecondsLeft] = useState(120);
    const [finished, setFinished] = useState(false);

    const inputRef = useRef(null);

    // 모달 상태 및 현재 포스터
    const [modalVisible, setModalVisible] = useState(false);
    const [currentPoster, setCurrentPoster] = useState(null);

    const timeUp = secondsLeft <= 0;
    const currentQ = questions[qIdx];

    // 목데이터 로드 (실제 fetch 대체)
    useEffect(() => {
        setLoading(true);
        setError('');
        const timer = setTimeout(() => {
            setQuestions(MOCK_QUESTIONS);
            setLoading(false);
        }, 2000);
        return () => clearTimeout(timer);
    }, []);

    // 타이머
    useEffect(() => {
        if (timeUp || finished) return;
        const id = setInterval(() => setSecondsLeft((s) => Math.max(0, s - 1)), 1000);
        return () => clearInterval(id);
    }, [timeUp, finished]);

    const mmss = useMemo(() => {
        const m = String(Math.floor(secondsLeft / 60));
        const s = String(secondsLeft % 60).padStart(2, '0');
        return `${m}:${s}`;
    }, [secondsLeft]);

    // 다음 문제 이동 함수
    const gotoNext = () => {
        setModalVisible(false);
        setCurrentPoster(null);
        setHintUsed(false);
        setHintText('');
        setMessage('');
        setGuess('');
        if (qIdx < questions.length - 1) {
            setQIdx((i) => i + 1);
        } else {
            setFinished(true);
        }
        inputRef.current?.focus();
    };

    // 힌트 보여주기
    const showHint = () => {
        if (hintUsed || timeUp || finished) return;
        setHintUsed(true);
        setHintText(toChosung(currentQ.answer));
        setHintCount((c) => c + 1);
        setMessage('초성 힌트를 사용했습니다.');
    };

    // 제출
    const submit = (e) => {
        e?.preventDefault();
        if (timeUp || finished || !guess.trim()) return;

        if (normalize(guess) === normalize(currentQ.answer)) {
            setCorrect((c) => c + 1);
            if (currentQ.posterUrl) {
                setCurrentPoster(currentQ.posterUrl);
                setModalVisible(true);
            } else {
                setMessage('포스터 정보가 없습니다.');
            }
        } else {
            setMessage('오답입니다. 다시 시도해보세요.');
            inputRef.current?.focus();
        }
    };

    // 패스
    const pass = () => {
        if (timeUp || finished) return;
        setPassCount((c) => c + 1);
        setMessage('패스했습니다.');
        gotoNext();
    };

    // 결과 보기 이동
    const goResult = () => {
        onFinish?.({
            correct,
            total: questions.length,
            timeUsed: 120 - secondsLeft,
            hintCount,
            passCount,
        });
    };

    if (loading)
        return (
            <div className="page page--play">
                <main className="canvas canvas--play" aria-busy="true" aria-live="polite">
                    문제를 불러오는 중...
                </main>
            </div>
        );
    if (error)
        return (
            <div className="page page--play">
                <main className="canvas canvas--play" role="alert">
                    ❗ {error}
                </main>
            </div>
        );
    if (!currentQ) return null;

    const isInputDisabled = timeUp || finished || modalVisible;

    return (
        <div className="page page--play">
            <main className="canvas canvas--play" role="main">
                {/* Header */}
                <header className="play-topbar">
                    <div className="left">
                        <span className="badge">
                            문제 {qIdx + 1} / {questions.length}
                        </span>
                    </div>
                    <div className={`timer ${secondsLeft <= 10 ? 'danger' : ''}`} aria-live="polite" aria-atomic="true">
                        ⏱ {mmss}
                    </div>
                    <div className="right">
                        <button className="btn btn--ghost" onClick={onExit} type="button">
                            나가기
                        </button>
                    </div>
                </header>
                {/* Emoji Board */}
                <section className="emoji-board" aria-label="이모지 퀴즈 힌트">
                    <div className="emoji-grid">
                        {currentQ.emojis?.length ? (
                            currentQ.emojis.map((emoji, i) => (
                                <div className="emoji-card" key={i} role="img" aria-label={`이모지 ${i + 1}`}>
                                    <span className="emoji-text">{emoji}</span>
                                </div>
                            ))
                        ) : (
                            <div className="emoji-empty">이모지가 없습니다.</div>
                        )}
                    </div>
                </section>
                {/* Input Area */}
                <section className="answer-area">
                    <form className="answer-form" onSubmit={submit}>
                        <input
                            ref={inputRef}
                            className="answer-input"
                            type="text"
                            placeholder="영화 제목을 입력하세요"
                            value={guess}
                            onChange={(e) => setGuess(e.target.value)}
                            disabled={isInputDisabled}
                            autoComplete="off"
                            aria-label="영화 제목 입력"
                        />
                        <div className="actions">
                            <button type="submit" className="btn btn--primary" disabled={isInputDisabled}>
                                제출
                            </button>
                            <button
                                type="button"
                                className="btn btn--secondary"
                                onClick={showHint}
                                disabled={hintUsed || isInputDisabled}
                            >
                                힌트
                            </button>
                            <button type="button" className="btn btn--ghost" onClick={pass} disabled={isInputDisabled}>
                                패스
                            </button>
                        </div>
                    </form>

                    <div className="hint-row">
                        {hintUsed ? (
                            <div className="hint-badge" aria-live="polite">
                                초성: {hintText}
                            </div>
                        ) : (
                            <div className="hint-badge hint-muted" aria-live="polite">
                                힌트를 누르면 초성이 표시됩니다
                            </div>
                        )}
                        {message && (
                            <div className="msg" role="status" aria-live="polite">
                                {message}
                            </div>
                        )}
                    </div>
                </section>
                {(timeUp || finished) && (
                    <div className="timeup" role="dialog" aria-modal="true" aria-labelledby="timeup-title">
                        <div className="timeup-card">
                            <h2 id="timeup-title" className="timeup-title">
                                {timeUp ? '시간 종료' : '라운드 종료'}
                            </h2>
                            <div className="timeup-actions">
                                <button className="btn btn--secondary" onClick={onExit} type="button">
                                    홈으로
                                </button>
                                <button className="btn btn--primary" onClick={goResult} type="button">
                                    결과 보기
                                </button>
                            </div>
                        </div>
                    </div>
                )}
                {/* Poster Modal */}
                {modalVisible && (
                    <div
                        className="modal-overlay"
                        role="dialog"
                        aria-modal="true"
                        aria-label="영화 포스터 모달"
                        onClick={() => {
                            setModalVisible(false);
                            gotoNext();
                        }}
                    >
                        <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                            <h2 style={{ marginBottom: '16px', fontWeight: '800', fontSize: '24px', color: '#111827' }}>
                                정답입니다!
                            </h2>
                            <img src={currentPoster} alt={`${currentQ.answer} 영화 포스터`} className="poster-image" />
                            <button
                                className="next-button"
                                onClick={() => {
                                    setModalVisible(false);
                                    gotoNext();
                                }}
                                type="button"
                            >
                                다음 문제
                            </button>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
}
