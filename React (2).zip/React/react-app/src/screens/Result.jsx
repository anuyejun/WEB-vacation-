import React, { useEffect, useMemo, useRef, useState } from 'react';
import './result.css';

function calcScore({ correct = 0, timeUsed = 0, hintCount = 0, passCount = 0 }) {
    const base = correct * 100;
    const speed = Math.max(0, 120 - timeUsed);
    const penalty = hintCount * 5 + passCount * 10;
    return Math.max(0, base + speed - penalty);
}

export default function Result({ data, onRetry, onHome }) {
    const myScore = useMemo(() => calcScore(data || {}), [data]);

    const [entries, setEntries] = useState([]);
    const [name, setName] = useState('');
    const [lastId, setLastId] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const nameRef = useRef(null);

    useEffect(() => {
        // 닉네임 입력창에 자동 포커스
        setTimeout(() => nameRef.current?.focus(), 50);

        // 초기 랭킹 데이터를 서버에서 불러올 수도 있음 (선택 사항)
        fetchRanking();
    }, []);

    const fetchRanking = async () => {
        try {
            const res = await fetch('/api/ranking');
            if (!res.ok) throw new Error('랭킹 데이터를 불러오지 못했습니다.');
            const rankings = await res.json();
            setEntries(rankings);
        } catch (err) {
            console.error(err);
            setError(err.message);
        }
    };

    // 서버에 점수와 닉네임 제출
    const submit = async (e) => {
        e?.preventDefault?.();
        const trimmed = (name || '').trim();
        if (!trimmed) return;

        setLoading(true);
        setError(null);

        try {
            const payload = {
                name: trimmed,
                score: myScore,
                correct: data?.correct ?? 0,
                total: data?.total ?? 0,
                timeUsed: data?.timeUsed ?? 0,
                hintCount: data?.hintCount ?? 0,
                passCount: data?.passCount ?? 0,
            };

            const res = await fetch('/api/ranking', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });

            if (!res.ok) {
                throw new Error('서버에 점수를 제출하지 못했습니다.');
            }

            const updatedRankings = await res.json();
            setEntries(updatedRankings);

            // 서버에서 보내주는 랭킹 리스트에서 내 기록 찾기 (id 혹은 이름 기준)
            // 여기서는 이름으로 찾음
            const me = updatedRankings.find((r) => r.name === trimmed);
            if (me) setLastId(me.id || null);

            setLoading(false);
        } catch (err) {
            setLoading(false);
            setError(err.message);
        }
    };

    // 시간 포맷 함수
    const mmss = (sec) => {
        const m = String(Math.floor(sec / 60));
        const s = String(sec % 60).padStart(2, '0');
        return `${m}:${s}`;
    };

    return (
        <div className="page page--result">
            <main className="canvas canvas--result">
                <header className="result-head">
                    <h2 className="title">결과 & 랭킹</h2>
                    <p className="sub">아래에 닉네임을 등록하면 서버 랭킹판에 반영됩니다</p>
                </header>

                <section className="mycard">
                    <div className="stat">
                        <div className="label">정답</div>
                        <div className="value">
                            {data?.correct ?? 0} / {data?.total ?? 0}
                        </div>
                    </div>
                    <div className="stat">
                        <div className="label">소요시간</div>
                        <div className="value">{mmss(data?.timeUsed ?? 0)}</div>
                    </div>
                    <div className="stat">
                        <div className="label">힌트/패스</div>
                        <div className="value">
                            {data?.hintCount ?? 0} / {data?.passCount ?? 0}
                        </div>
                    </div>
                    <div className="stat highlight">
                        <div className="label">점수</div>
                        <div className="value big">{myScore}</div>
                    </div>
                </section>

                <section className="register">
                    <form className="reg-form" onSubmit={submit}>
                        <input
                            ref={nameRef}
                            type="text"
                            className="nick-input"
                            placeholder="닉네임을 입력하세요 (예: popcorn123)"
                            maxLength={20}
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            disabled={loading}
                        />
                        <button type="submit" className="btn btn--primary" disabled={loading}>
                            {loading ? '등록 중...' : '랭킹 등록'}
                        </button>
                    </form>
                    {error && <p style={{ color: 'red', marginTop: 8 }}>{error}</p>}
                </section>

                <section className="board">
                    <div className="board-head">Top 10</div>
                    <div className="table">
                        <div className="row header">
                            <div className="col rank">#</div>
                            <div className="col name">닉네임</div>
                            <div className="col score">점수</div>
                        </div>
                        {entries.length ? (
                            entries.slice(0, 10).map((r, i) => {
                                const isNew = r.id === lastId;
                                return (
                                    <div key={r.id ?? r.ts ?? i} className={`row ${isNew ? 'new' : ''}`}>
                                        <div className="col rank">{i + 1}</div>
                                        <div className="col name">{r.name}</div>
                                        <div className="col score">{r.score}</div>
                                        <div className="col detail">
                                            {r.correct}/{r.total} • {mmss(r.timeUsed)}
                                        </div>
                                    </div>
                                );
                            })
                        ) : (
                            <div className="row empty">아직 등록된 기록이 없습니다.</div>
                        )}
                    </div>
                </section>

                <section className="result-actions">
                    <button className="btn btn--secondary" onClick={onHome}>
                        홈으로
                    </button>
                    <button className="btn btn--primary" onClick={onRetry}>
                        다시하기
                    </button>
                </section>
            </main>
        </div>
    );
}
